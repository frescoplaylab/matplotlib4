import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.testing.decorators import image_comparison

@image_comparison(baseline_images=['Histogram'],extensions=['png'])
def test_hist_of_a_sample_normal_distribution():

    # Write your functionality below


@image_comparison(baseline_images=['Boxplot'],extensions=['png'])
def test_boxplot_of_four_normal_distribution():

    # Write your functionality below


