from django.conf.urls import include, url

from .views import displayimage1, displayimage2

urlpatterns = [
    url(r'^1/$', displayimage1),
    url(r'^2/$', displayimage2),
]
